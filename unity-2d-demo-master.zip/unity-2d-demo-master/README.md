OUYA Unity 2D Demo
=============

This is the demo Unity project for the video found here: http://vimeo.com/102651617

Follow along and submit a complete game for the OUYA in 20 minutes! [Text version here](https://devs.ouya.tv/developers/docs/make_a_game_in_20_minutes)

**Building**

The unitypackage file is created running the `makepackage.sh` script from the root folder. Currently, the script is MacOS-only, and requires an installation of Unity

**Thanks**

Special thanks to Unity for letting us fork [their 2D sample game](https://www.assetstore.unity3d.com/#/content/11228), Bryan for the awesome art, and [Landon Podbielski](http://wonthelp.info) for the great music!
